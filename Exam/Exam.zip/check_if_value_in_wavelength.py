def check_if_value_in_wavelength(value, wavelength):
    return value in (wavelength / 10)